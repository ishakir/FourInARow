import scala.annotation.tailrec
import scala.util.Random

/**
 * Created by imran on 29/11/15.
 */
class Move(state: State) {
  val board = state.game.currentRound.board
  val columnsIndices = board(0).zipWithIndex.map { case (content, index) => index }.toSeq

  def chooseColumn(): Int = {
    val winners = completions(Me)
    if(!winners.isEmpty) winners(0) else {
      val blockers = completions(Opponent)
      if(!blockers.isEmpty) blockers(0) else {
        Random.shuffle(columnsIndices).head
      }
    }
  }

  def completions(matcher: Cell) = {
    columnsIndices.filter { i =>
      board.map(arr => arr(i)).zipWithIndex.reverse.find { case(cell, index) => cell == Empty }.exists { case (cell, j) =>
        Seq((-1, -1), (-1, 0), (-1, 1), (0, -1), (0, 1), (1, -1), (1, 0), (1, 1)).exists { case (dir1, dir2) =>
          willComplete(i + dir1, j + dir2, dir1, dir2, matcher, 3)
        }
      }
    }
  }

  private def willComplete(i: Int, j: Int, dir1: Int, dir2: Int, matcher: Cell, remaining: Int): Boolean = {
    if(remaining == 0) true else {
      try {
        if(board(j)(i) == matcher) willComplete(i + dir1, j + dir2, dir1, dir2, matcher, remaining - 1) else false
      } catch {
        case e: IndexOutOfBoundsException => false
      }
    }
  }
}
